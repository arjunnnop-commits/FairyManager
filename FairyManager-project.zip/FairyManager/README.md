# Fairy Manager
Built by @yooitachiijod · https://t.me/FairysTeamBase

Root app for cool peak performance: heat guard, game auto-detect, one-tap bypass charging, charge limit. Gold and black glass UI.

Logo: `app/src/main/res/drawable-nodpi/fairy_team_logo.png` (used in Support, splash and the app icon).
