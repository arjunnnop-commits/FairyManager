# Fairy Manager
Built by @yooitachiijod · https://t.me/FairysTeamBase

Root app for gaming and battery saving: power profiles, game auto-detect, bypass charging, charge limit up to 100%.

Replace the logo: delete `app/src/main/res/drawable/fairy_logo.xml` and add your `fairy_logo.png` to `app/src/main/res/drawable-nodpi/` (used for the app icon, splash and About).
