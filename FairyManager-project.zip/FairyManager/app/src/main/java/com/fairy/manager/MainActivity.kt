package com.fairy.manager

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.fairy.manager.core.FairyViewModel
import com.fairy.manager.ui.FairyApp
import com.fairy.manager.ui.FairyTheme

class MainActivity : ComponentActivity() {
    private val vm: FairyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            FairyTheme {
                FairyApp(vm)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.setActive(true)
    }

    override fun onStop() {
        super.onStop()
        vm.setActive(false)
    }
}
