package com.fairy.manager.core

import java.io.BufferedReader
import java.io.OutputStreamWriter

/** Root shell helper. A persistent `su` session for quick commands, one-shot `su -c` for long ones. */
object Root {
    private const val MARK = "__FAIRY_END__"
    private var proc: Process? = null
    private var writer: OutputStreamWriter? = null
    private var reader: BufferedReader? = null

    @Synchronized
    private fun open(): Boolean {
        val current = proc
        if (current != null) {
            try {
                current.exitValue()
                proc = null
            } catch (e: IllegalThreadStateException) {
                return true
            }
        }
        return try {
            val p = ProcessBuilder("su").redirectErrorStream(true).start()
            proc = p
            writer = OutputStreamWriter(p.outputStream)
            reader = p.inputStream.bufferedReader()
            true
        } catch (e: Exception) {
            proc = null
            false
        }
    }

    @Synchronized
    private fun close() {
        try { proc?.destroy() } catch (e: Exception) { }
        proc = null
        writer = null
        reader = null
    }

    /** Runs a quick command in the persistent root shell and returns its output. */
    @Synchronized
    fun sh(cmd: String): String {
        if (!open()) return ""
        return try {
            val w = writer!!
            val r = reader!!
            w.write(cmd + "\necho " + MARK + "\n")
            w.flush()
            val sb = StringBuilder()
            while (true) {
                val line = r.readLine()
                if (line == null) {
                    close()
                    break
                }
                if (line == MARK) break
                sb.append(line).append('\n')
            }
            sb.toString().trimEnd()
        } catch (e: Exception) {
            close()
            ""
        }
    }

    /** Runs a long command in its own root process (does not block the persistent shell). */
    fun long(cmd: String): String {
        return try {
            val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            val text = p.inputStream.bufferedReader().readText()
            p.waitFor()
            text.trim()
        } catch (e: Exception) {
            "Error: " + (e.message ?: "unknown")
        }
    }

    fun check(): Boolean = sh("id -u").trim() == "0"
}
