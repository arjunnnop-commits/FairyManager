package com.fairy.manager.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0A14)
val Surface1 = Color(0xFF14122B)
val Surface2 = Color(0xFF1E1B45)
val Violet = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val Pink = Color(0xFFF472B6)
val Green = Color(0xFF34D399)
val Amber = Color(0xFFFBBF24)
val Red = Color(0xFFF87171)
val TextHi = Color(0xFFF5F3FF)
val TextLo = Color(0xFF9A96C0)

@Composable
fun FairyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            secondary = Cyan,
            background = Bg,
            surface = Surface1,
            onPrimary = Color.White,
            onBackground = TextHi,
            onSurface = TextHi
        ),
        content = content
    )
}
