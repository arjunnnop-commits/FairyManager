package com.fairy.manager.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF000000)
val Gold = Color(0xFFF2B632)
val GoldSoft = Color(0xFFFFD87A)
val GoldDeep = Color(0xFF8A6A1F)
val Surface1 = Color(0xFF0C0B08)
val Surface2 = Color(0xFF17140C)
val TextHi = Color(0xFFF6F1E4)
val TextLo = Color(0xFF9B9482)
val Hot = Color(0xFFFF6B5E)
val Cool = Color(0xFF8FD9A8)
val Hairline = Color(0x1FFFFFFF)

private val Scheme = darkColorScheme(
    primary = Gold,
    onPrimary = Color.Black,
    background = Bg,
    onBackground = TextHi,
    surface = Surface1,
    onSurface = TextHi,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextLo,
    outline = Hairline
)

@Composable
fun FairyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
