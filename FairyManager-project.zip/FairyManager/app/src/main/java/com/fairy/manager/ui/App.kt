package com.fairy.manager.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairy.manager.core.FairyViewModel

private val NAV_LABELS = listOf("Home", "Hubs", "Support", "Settings")

private fun navIcon(i: Int): ImageVector = when (i) {
    0 -> Icons.Rounded.Home
    1 -> Icons.Rounded.GridView
    2 -> Icons.Rounded.Favorite
    else -> Icons.Rounded.Settings
}

@Composable
fun FairyApp(vm: FairyViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var sub by rememberSaveable { mutableStateOf("") }
    var splash by rememberSaveable { mutableStateOf(true) }
    val ctx = LocalContext.current

    LaunchedEffect(vm.toast) {
        val msg = vm.toast
        if (msg != null) {
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            vm.toast = null
        }
    }

    BackHandler(enabled = sub.isNotEmpty()) { sub = "" }

    Box(modifier = Modifier.fillMaxSize()) {
        FairyBackground(Modifier.fillMaxSize())
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            if (sub.isNotEmpty()) {
                SubScreen(vm, sub) { sub = "" }
            } else {
                when (tab) {
                    0 -> HomeScreen(vm)
                    1 -> HubsScreen(vm) { sub = it }
                    2 -> SupportScreen()
                    else -> SettingsScreen(vm)
                }
            }
        }
        FloatingNav(
            selected = tab,
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            tab = it
            sub = ""
        }
        if (splash) {
            SplashOverlay { splash = false }
        }
    }
}

@Composable
private fun FloatingNav(selected: Int, modifier: Modifier, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Row(
        modifier = modifier
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 12.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1A170E), Color(0xFF0B0A06))))
            .border(1.dp, Brush.linearGradient(listOf(Color(0x40FFFFFF), Color(0x10FFFFFF))), shape)
            .padding(6.dp)
    ) {
        for (i in NAV_LABELS.indices) {
            val on = i == selected
            val itemShape = RoundedCornerShape(24.dp)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(itemShape)
                    .background(if (on) Gold.copy(alpha = 0.16f) else Color.Transparent)
                    .border(1.dp, if (on) Gold.copy(alpha = 0.5f) else Color.Transparent, itemShape)
                    .clickable { onSelect(i) }
                    .padding(vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(navIcon(i), contentDescription = null, tint = if (on) Gold else TextLo, modifier = Modifier.size(22.dp))
                Text(
                    NAV_LABELS[i],
                    color = if (on) Gold else TextLo,
                    fontSize = 11.sp,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}
