package com.fairy.manager.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairy.manager.core.FairyViewModel

private val TAB_LABELS = listOf("Home", "Modes", "Games", "Charge", "Tools")
private val TAB_GLYPHS = listOf("🏠", "⚡", "🎮", "🔋", "🛠️")

@Composable
fun FairyApp(vm: FairyViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAbout by rememberSaveable { mutableStateOf(false) }
    var splash by rememberSaveable { mutableStateOf(true) }
    val ctx = LocalContext.current

    LaunchedEffect(vm.toast) {
        val msg = vm.toast
        if (msg != null) {
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            vm.toast = null
        }
    }

    BackHandler(enabled = showAbout) { showAbout = false }

    Box(modifier = Modifier.fillMaxSize()) {
        AuroraBackground(Modifier.fillMaxSize())
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            TopBar(vm) { showAbout = true }
            Box(modifier = Modifier.weight(1f)) {
                Crossfade(targetState = tab, animationSpec = tween(250), label = "tabs") { t ->
                    when (t) {
                        0 -> HomeScreen(vm)
                        1 -> ModesScreen(vm)
                        2 -> GamesScreen(vm)
                        3 -> ChargeScreen(vm)
                        else -> ToolsScreen(vm)
                    }
                }
            }
            BottomNav(tab) { tab = it }
        }
        AnimatedVisibility(
            visible = showAbout,
            enter = fadeIn(tween(250)) + slideInVertically(tween(300)) { it / 8 },
            exit = fadeOut(tween(200)) + slideOutVertically(tween(250)) { it / 8 }
        ) {
            AboutScreen { showAbout = false }
        }
        if (splash) {
            SplashOverlay { splash = false }
        }
    }
}

@Composable
private fun TopBar(vm: FairyViewModel, onAbout: () -> Unit) {
    val sub = when {
        vm.root == null -> "Checking root..."
        vm.root == false -> "No root access"
        vm.daemon -> "Engine running"
        else -> "Engine stopped"
    }
    val dot = when {
        vm.root != true -> Color(0xFFF87171)
        vm.daemon -> Green
        else -> Amber
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.clickable(onClick = onAbout)) {
            FairyLogo(40.dp)
        }
        Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
            Text("Fairy Manager", color = TextHi, fontSize = 19.sp, fontWeight = FontWeight.Black)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(dot))
                Text(sub, color = TextLo, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
            }
        }
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Surface2)
                .border(1.dp, Color(0x33FFFFFF), CircleShape)
                .clickable(onClick = onAbout),
            contentAlignment = Alignment.Center
        ) {
            Text("i", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier = Modifier
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Surface1.copy(alpha = 0.96f))
            .border(1.dp, Color(0x22FFFFFF), shape)
            .padding(6.dp)
    ) {
        TAB_LABELS.forEachIndexed { i, label ->
            val sel = i == selected
            val bg by animateColorAsState(if (sel) Violet.copy(alpha = 0.28f) else Color.Transparent, label = "nav")
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(TAB_GLYPHS[i], fontSize = 20.sp, modifier = Modifier.alpha(if (sel) 1f else 0.6f))
                Text(
                    label,
                    fontSize = 11.sp,
                    color = if (sel) TextHi else TextLo,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}
