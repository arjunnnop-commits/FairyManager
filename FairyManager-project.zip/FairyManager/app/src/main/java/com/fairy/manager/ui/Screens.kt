package com.fairy.manager.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairy.manager.core.Core
import com.fairy.manager.core.Cpu
import com.fairy.manager.core.FairyViewModel
import java.util.Locale

private fun fmt(v: Float, digits: Int): String = String.format(Locale.US, "%." + digits + "f", v)

@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

// ============================================================ shared pieces

@Composable
fun StatusBanners(vm: FairyViewModel) {
    if (vm.root == null) {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Amber) {
            Text("Requesting root access...", color = TextHi, fontWeight = FontWeight.Bold)
            Text("Approve the Superuser prompt to continue.", color = TextLo, fontSize = 12.sp)
        }
    } else if (vm.root == false) {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Red) {
            Text("Root access required", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                "Grant Superuser permission to Fairy Manager in Magisk, KernelSU or APatch, then tap retry.",
                color = TextLo,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            FairyButton("Retry", Modifier.fillMaxWidth(), accent = Red) { vm.retryRoot() }
        }
    } else if (!vm.coreInstalled) {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Amber) {
            Text("Core not installed", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                "Install the Fairy core to enable bypass charging, profiles and game detection.",
                color = TextLo,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            FairyButton("Install core", Modifier.fillMaxWidth(), accent = Amber, enabled = !vm.busy) { vm.installCore() }
        }
    } else if (vm.coreVer < Core.VERSION) {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Cyan) {
            Text("Core update available", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                "Update to unlock the 100% charge limit and all new settings.",
                color = TextLo,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            FairyButton("Update core", Modifier.fillMaxWidth(), accent = Cyan, enabled = !vm.busy) { vm.installCore() }
        }
    }
}

@Composable
fun StatTile(modifier: Modifier, glyph: String, label: String, value: String, accent: Color = Violet) {
    GlassCard(modifier = modifier, accent = accent) {
        Text(glyph, fontSize = 22.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = TextLo, fontSize = 12.sp)
    }
}

@Composable
fun QuickAction(modifier: Modifier, glyph: String, label: String, active: Boolean, accent: Color, onClick: () -> Unit) {
    val bg by animateColorAsState(if (active) accent.copy(alpha = 0.28f) else Surface1, label = "qa")
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(bg)
            .border(1.dp, if (active) accent else Color(0x22FFFFFF), shape)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(glyph, fontSize = 24.sp)
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (active) TextHi else TextLo, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun BatteryRing(level: Int, status: String) {
    val prog by animateFloatAsState(level / 100f, tween(900), label = "lvl")
    val color = when {
        level <= 15 -> Red
        level <= 40 -> Amber
        else -> Green
    }
    Box(modifier = Modifier.size(210.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 18.dp.toPx()
            val inset = stroke / 2f
            val arcSize = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = Color(0x22FFFFFF),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            rotate(-90f) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(color.copy(alpha = 0.45f), color)),
                    startAngle = 0f,
                    sweepAngle = 360f * prog,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(level.toString() + "%", color = TextHi, fontSize = 46.sp, fontWeight = FontWeight.Black)
            Text(status, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun CpuRow(c: Cpu, idx: Int) {
    val frac = if (c.maxKhz > 0) (c.curKhz.toFloat() / c.maxKhz).coerceIn(0f, 1f) else 0f
    val anim by animateFloatAsState(frac, tween(600), label = "cpu")
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text("Cluster " + idx + "  (cap " + (c.maxKhz / 1000) + ")", color = TextHi, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text((c.curKhz / 1000).toString() + " MHz", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Bg.copy(alpha = 0.6f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(anim)
                    .background(Brush.horizontalGradient(listOf(Violet, Cyan)))
            )
        }
    }
}

private val PROFILE_OPTIONS = listOf("auto" to "Auto", "low" to "Saver", "mid" to "Balanced", "high" to "Perf")
private val LEVEL_OPTIONS = listOf("low" to "Saver", "mid" to "Balanced", "high" to "Performance")

// ============================================================ HOME

@Composable
fun HomeScreen(vm: FairyViewModel) {
    val s = vm.stats
    val mode = vm.cfgStr("MODE", "auto")
    val tempColor = when {
        s.tempC >= 43f -> Red
        s.tempC >= 38f -> Amber
        else -> Green
    }
    ScreenColumn {
        StatusBanners(vm)
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Cyan) {
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                BatteryRing(s.level, s.status)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Modifier.weight(1f), "🌡️", "Temperature", fmt(s.tempC, 1) + " °C", tempColor)
            StatTile(Modifier.weight(1f), "⚡", "Current", s.currentMa.toString() + " mA", Cyan)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Modifier.weight(1f), "🔌", "Voltage", fmt(s.voltageV, 2) + " V", Violet)
            StatTile(Modifier.weight(1f), "💡", "Power", fmt(s.powerW, 1) + " W", Pink)
        }

        SectionTitle("Quick actions")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickAction(Modifier.weight(1f), "🎮", "Game Boost", mode == "high", Pink) { vm.toggleBoost() }
            QuickAction(Modifier.weight(1f), "🧹", "Clean RAM", false, Cyan) { vm.cleanRam() }
            QuickAction(Modifier.weight(1f), "🍃", "Saver", mode == "low", Green) { vm.toggleSaver() }
        }

        SectionTitle("Power profile")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Segmented(PROFILE_OPTIONS, mode) { vm.setMode(it) }
        }

        if (s.memTotalMb > 0) {
            SectionTitle("Memory")
            GlassCard(modifier = Modifier.fillMaxWidth(), accent = Cyan) {
                val used = (s.memTotalMb - s.memFreeMb).coerceAtLeast(0)
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Free RAM", color = TextHi, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(s.memFreeMb.toString() + " / " + s.memTotalMb + " MB", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Bg.copy(alpha = 0.6f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth((used.toFloat() / s.memTotalMb).coerceIn(0f, 1f))
                            .background(Brush.horizontalGradient(listOf(Cyan, Pink)))
                    )
                }
            }
        }

        if (s.cpus.isNotEmpty()) {
            SectionTitle("CPU clusters")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                s.cpus.forEachIndexed { i, c -> CpuRow(c, i) }
            }
        }

        SectionTitle("Engine")
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = if (vm.daemon) Green else Red) {
            ToggleRow(
                "Fairy Engine",
                if (vm.daemon) "Running: profiles, game detection and charging control are active" else "Stopped: nothing is being managed",
                vm.daemon
            ) { vm.setDaemon(it) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ============================================================ MODES

private class Profile(val key: String, val glyph: String, val title: String, val desc: String, val accent: Color)

@Composable
fun ModesScreen(vm: FairyViewModel) {
    val mode = vm.cfgStr("MODE", "auto")
    val low = vm.cfgInt("LOW_PCT", 45)
    val mid = vm.cfgInt("MID_PCT", 70)
    val tempLimit = vm.cfgInt("TEMP_LIMIT", 450) / 10
    val profiles = listOf(
        Profile("auto", "✨", "Auto", "Performance in games, balanced everywhere else", Cyan),
        Profile("low", "🍃", "Battery Saver", "CPU capped at " + low + "% for the longest battery life", Green),
        Profile("mid", "⚖️", "Balanced", "CPU capped at " + mid + "% for smooth daily use", Violet),
        Profile("high", "🔥", "Performance", "Full CPU power for maximum gaming speed", Pink)
    )
    ScreenColumn {
        StatusBanners(vm)
        SectionTitle("Power profile")
        profiles.forEach { p ->
            val sel = p.key == mode
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                accent = if (sel) p.accent else Color(0xFF3A3668),
                onClick = { vm.setMode(p.key) }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.glyph, fontSize = 30.sp)
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(p.title, color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(p.desc, color = TextLo, fontSize = 12.sp)
                    }
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(if (sel) p.accent else Color.Transparent)
                            .border(2.dp, if (sel) p.accent else Color(0x44FFFFFF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (sel) Text("✓", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        SectionTitle("Auto mode rules")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Everyday profile", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Used whenever no game is running", color = TextLo, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Segmented(LEVEL_OPTIONS, vm.cfgStr("DEFAULT_MODE", "mid")) { vm.setCfg("DEFAULT_MODE", it) }
            Spacer(Modifier.height(16.dp))
            Text("In-game profile", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Used while a game from your Game Space is open", color = TextLo, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Segmented(LEVEL_OPTIONS, vm.cfgStr("GAME_MODE", "high"), accent = Pink) { vm.setCfg("GAME_MODE", it) }
        }

        SectionTitle("Fine tuning")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            LabeledSlider("Saver CPU cap", low, 20, 70, "%", Green) {
                vm.setCfg("LOW_PCT", minOf(it, mid - 5).toString())
            }
            LabeledSlider("Balanced CPU cap", mid, 50, 95, "%", Violet) {
                vm.setCfg("MID_PCT", maxOf(it, low + 5).toString())
            }
            LabeledSlider("Thermal guard", tempLimit, 35, 50, " °C", Amber) {
                vm.setCfg("TEMP_LIMIT", (it * 10).toString())
            }
            Text(
                "When the battery gets hotter than the thermal guard, Performance steps down to Balanced and 3 °C above that to Saver.",
                color = TextLo,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ============================================================ CHARGE

@Composable
fun ChargeScreen(vm: FairyViewModel) {
    val bypass = vm.cfgStr("BYPASS", "auto")
    val limit = vm.cfgInt("CHARGE_LIMIT", 0)
    var draft by remember(limit) { mutableIntStateOf(if (limit > 0) limit else 80) }
    val desc = when (bypass) {
        "on" -> "Bypass is forced on. The phone runs straight from the charger and the battery is left alone."
        "off" -> "Normal charging. Bypass is never used."
        else -> "Bypass turns on by itself while gaming and when the charge limit is reached."
    }
    ScreenColumn {
        StatusBanners(vm)
        SectionTitle("Bypass charging")
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Cyan) {
            Segmented(listOf("auto" to "Auto", "on" to "Always on", "off" to "Off"), bypass, accent = Cyan) {
                vm.setCfg("BYPASS", it)
            }
            Spacer(Modifier.height(10.dp))
            Text(desc, color = TextLo, fontSize = 12.sp)
        }

        SectionTitle("Charge limit")
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Green) {
            ToggleRow(
                "Limit charging",
                if (limit > 0) "Stops at " + limit + "% and resumes at " + maxOf(limit - 5, 0) + "%" else "Off: charges to full as usual",
                limit > 0
            ) { on -> vm.setCfg("CHARGE_LIMIT", if (on) draft.toString() else "0") }
            LabeledSlider("Limit", draft, 50, 100, "%", Green, enabled = limit > 0) {
                draft = it
                vm.setCfg("CHARGE_LIMIT", it.toString())
            }
            Text(
                "Keeping the battery between 20% and 80% makes it last longer. Set 100% for a normal full charge.",
                color = TextLo,
                fontSize = 12.sp
            )
        }

        SectionTitle("Live charging data")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Modifier.weight(1f), "⚡", "Current", vm.stats.currentMa.toString() + " mA", Cyan)
            StatTile(Modifier.weight(1f), "💡", "Power", fmt(vm.stats.powerW, 1) + " W", Pink)
        }

        SectionTitle("Charging node")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            val parts = vm.node.split(" ")
            if (vm.node.isBlank()) {
                Text("Not detected yet", color = Amber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Open Tools and run Detect nodes, then Test bypass with the charger connected.", color = TextLo, fontSize = 12.sp)
            } else {
                Text("Detected", color = Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(parts[0], color = TextHi, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text("Run Test bypass in Tools to verify it.", color = TextLo, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ============================================================ TOOLS

@Composable
fun ToolsScreen(vm: FairyViewModel) {
    LaunchedEffect(Unit) { vm.refreshSystem() }
    ScreenColumn {
        StatusBanners(vm)

        SectionTitle("Gaming and battery tweaks")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            ToggleRow("System battery saver", "Android's own low power mode", vm.sys.lowPower) { vm.setLowPower(it) }
            ToggleRow("Gaming DND", "Silence notifications and calls while you play", vm.sys.dnd) { vm.setDnd(it) }
            ToggleRow("Faster animations", "Animation speed 0.5x for a snappier UI", vm.sys.fastAnim) { vm.setFastAnim(it) }
            Spacer(Modifier.height(8.dp))
            Text("Refresh rate", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("Lock 60 Hz to save battery or 120 Hz for gaming. Support varies by device.", color = TextLo, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("auto" to "Auto", "60" to "60", "90" to "90", "120" to "120"), vm.sys.refresh, accent = Cyan) {
                vm.setRefresh(it)
            }
        }

        SectionTitle("Memory")
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = Cyan) {
            Text(
                "Free RAM: " + vm.stats.memFreeMb + " MB of " + vm.stats.memTotalMb + " MB",
                color = TextHi,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(10.dp))
            FairyButton("Clean RAM now", Modifier.fillMaxWidth(), accent = Cyan) { vm.cleanRam() }
        }

        SectionTitle("Fairy core")
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = if (vm.coreInstalled) Green else Amber) {
            val status = when {
                !vm.coreInstalled -> "Not installed"
                vm.coreVer < Core.VERSION -> "Installed, update available"
                else -> "Installed and up to date"
            }
            Text(status, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Engine: " + (if (vm.daemon) "running" else "stopped"), color = TextLo, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FairyButton(
                    if (vm.coreInstalled) "Reinstall core" else "Install core",
                    Modifier.weight(1f),
                    enabled = !vm.busy
                ) { vm.installCore() }
                FairyButton(
                    if (vm.daemon) "Stop engine" else "Start engine",
                    Modifier.weight(1f),
                    accent = if (vm.daemon) Red else Green
                ) { vm.setDaemon(!vm.daemon) }
            }
        }

        SectionTitle("Diagnostics")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FairyButton("Detect nodes", Modifier.weight(1f), enabled = !vm.busy) { vm.runTool("detect") }
                FairyButton("Test bypass", Modifier.weight(1f), accent = Pink, enabled = !vm.busy) { vm.runTool("test") }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FairyButton("Probe", Modifier.weight(1f), accent = Cyan, enabled = !vm.busy) { vm.runTool("probe") }
                FairyButton("Status", Modifier.weight(1f), accent = Green, enabled = !vm.busy) { vm.runTool("status") }
            }
            Spacer(Modifier.height(10.dp))
            FairyButton("Reset node", Modifier.fillMaxWidth(), accent = Amber, enabled = !vm.busy) { vm.runTool("nodereset") }
            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 90.dp, max = 280.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF05040C))
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp)
            ) {
                Text(
                    if (vm.toolOutput.isBlank()) "Output will appear here" else vm.toolOutput,
                    color = Green,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Start
                )
            }
            Text("Test bypass needs the charger connected.", color = TextLo, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
}
