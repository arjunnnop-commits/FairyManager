package com.fairy.manager.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.NorthEast
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairy.manager.R
import com.fairy.manager.core.FairyViewModel
import java.util.Locale

private fun f(v: Float, digits: Int): String = String.format(Locale.US, "%." + digits + "f", v)

private fun modeName(m: String): String = when (m) {
    "low" -> "Cool"
    "mid" -> "Balanced"
    "high" -> "Peak"
    else -> "Smart Auto"
}

private fun modeDesc(m: String): String = when (m) {
    "low" -> "Lowest heat and longest battery"
    "mid" -> "Smooth everyday speed, stays cool"
    "high" -> "Maximum speed, heat guard trims only when hot"
    else -> "Peak in games, balanced everywhere else"
}

private fun tempColor(t: Float): Color = if (t >= 42f) Hot else if (t >= 38f) Gold else Cool
private fun tempWord(t: Float): String = if (t >= 42f) "Hot" else if (t >= 38f) "Warm" else "Cool"

@Composable
fun StatusBanners(vm: FairyViewModel) {
    if (vm.root == false) {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = true) {
            Text("Root access required", color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Grant root to Fairy Manager in your root manager, then retry.", color = TextLo, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            GoldButton("Retry root", Modifier.fillMaxWidth()) { vm.retryRoot() }
        }
    } else if (vm.root == true && !vm.coreInstalled) {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = true) {
            Text("Core not installed", color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("The core runs the performance, heat and charging engine.", color = TextLo, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            GoldButton(if (vm.busy) "Installing..." else "Install core", Modifier.fillMaxWidth()) { vm.installCore() }
        }
    }
}

@Composable
private fun RowScope.MiniStat(label: String, value: String, color: Color = TextHi) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier
            .weight(1f)
            .clip(shape)
            .background(Color(0x0FFFFFFF))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(label.uppercase(), color = TextLo, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun HwCell(modifier: Modifier, icon: ImageVector, label: String, value: String, sub: String, subColor: Color = TextLo) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        IconTile(icon, size = 40.dp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label.uppercase(), color = TextLo, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(sub, color = subColor, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun QuickTile(modifier: Modifier, icon: ImageVector, label: String, state: String, on: Boolean, onClick: () -> Unit) {
    GlassCard(modifier = modifier, accent = on, onClick = onClick) {
        IconTile(icon, tint = if (on) Gold else TextLo, size = 38.dp)
        Spacer(Modifier.height(10.dp))
        Text(label, color = TextHi, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(state, color = if (on) Gold else TextLo, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ============================================================ HOME

@Composable
fun HomeScreen(vm: FairyViewModel) {
    val s = vm.stats
    val mode = vm.cfgStr("MODE", "auto")
    val heatOn = vm.cfgStr("HEAT_GUARD", "1") == "1"
    ScreenColumn {
        ScreenTitle("Fairy Manager", "Cool peak performance.")
        StatusBanners(vm)

        GlassCard(modifier = Modifier.fillMaxWidth(), accent = true) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RingGauge(s.level / 100f, s.level.toString() + "%", s.status)
                Spacer(Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    StatusPill(
                        if (vm.root == true) (if (vm.daemon) "Engine live" else "Engine idle") else "No root",
                        if (vm.root == true && vm.daemon) Gold else TextLo
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(modeName(mode), color = TextHi, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(modeDesc(mode), color = TextLo, fontSize = 12.sp, lineHeight = 16.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat("Temp", f(s.tempC, 1) + "\u00B0C", tempColor(s.tempC))
                MiniStat("Power", f(s.powerW, 1) + " W")
                MiniStat("Cores", if (s.coresTotal > 0) s.cores.toString() + "/" + s.coresTotal else "--")
            }
        }

        SectionTitle("Live hardware")
        val top = s.cpus.maxOfOrNull { it.curKhz } ?: 0
        val used = (s.memTotalMb - s.memFreeMb).coerceAtLeast(0)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth()) {
                HwCell(Modifier.weight(1f), Icons.Rounded.Memory, "CPU", if (top > 0) f(top / 1_000_000f, 2) + " GHz" else "--", "Fastest core")
                HwCell(Modifier.weight(1f), Icons.Rounded.SportsEsports, "GPU", if (s.gpuMhz > 0) s.gpuMhz.toString() + " MHz" else "--", "Live clock")
            }
            Spacer(Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                HwCell(
                    Modifier.weight(1f), Icons.Rounded.Speed, "Memory",
                    if (s.memTotalMb > 0) f(used / 1024f, 1) + " GB" else "--",
                    if (s.memTotalMb > 0) "of " + f(s.memTotalMb / 1024f, 1) + " GB" else ""
                )
                HwCell(
                    Modifier.weight(1f), Icons.Rounded.Thermostat, "Heat", tempWord(s.tempC),
                    if (heatOn) "Guard on" else "Guard off", tempColor(s.tempC)
                )
            }
        }

        SectionTitle("Quick controls")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            QuickTile(Modifier.weight(1f), Icons.Rounded.BatteryChargingFull, "Bypass", if (vm.bypassOn) "ON" else "OFF", vm.bypassOn) {
                vm.setBypass(!vm.bypassOn)
            }
            QuickTile(Modifier.weight(1f), Icons.Rounded.Whatshot, "Heat guard", if (heatOn) "ON" else "OFF", heatOn) {
                vm.setCfg("HEAT_GUARD", if (heatOn) "0" else "1")
            }
            QuickTile(Modifier.weight(1f), Icons.Rounded.Refresh, "Clean RAM", "TAP", false) { vm.cleanRam() }
        }
    }
}

// ============================================================ HUBS

@Composable
private fun HubRow(icon: ImageVector, title: String, sub: String, trailing: String?, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTile(icon, size = 46.dp)
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = TextLo, fontSize = 12.sp)
        }
        if (trailing != null) {
            StatusPill(trailing)
            Spacer(Modifier.width(6.dp))
        }
        Icon(Icons.Rounded.KeyboardArrowRight, contentDescription = null, tint = TextLo)
    }
}

@Composable
private fun Divider() {
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Hairline))
}

@Composable
fun HubsScreen(vm: FairyViewModel, open: (String) -> Unit) {
    val s = vm.stats
    val top = s.cpus.maxOfOrNull { it.curKhz } ?: 0
    ScreenColumn {
        ScreenTitle("Control Hubs", "Performance, charging and system controls")
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = true) {
            Text("Hardware controls", color = TextLo, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("Control beyond cores.", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat("Battery", s.level.toString() + "%")
                MiniStat("CPU", if (top > 0) f(top / 1_000_000f, 1) + " GHz" else "--")
                MiniStat("GPU", if (s.gpuMhz > 0) s.gpuMhz.toString() + " MHz" else "--")
            }
        }
        SectionTitle("Performance")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            HubRow(Icons.Rounded.Bolt, "Performance Modes", "Cool, Balanced, Peak and heat guard", modeName(vm.cfgStr("MODE", "auto"))) { open("perf") }
            Divider()
            HubRow(Icons.Rounded.Memory, "CPU Core & Frequency", "Live clusters and clock ranges", null) { open("cpu") }
            Divider()
            HubRow(Icons.Rounded.SportsEsports, "Game List", vm.games.size.toString() + " games use the game profile", null) { open("games") }
        }
        SectionTitle("Power")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            HubRow(Icons.Rounded.BatteryChargingFull, "Charging Control", "Bypass charging and smart charging", if (vm.bypassOn) "Bypass on" else null) { open("charge") }
            Divider()
            HubRow(Icons.Rounded.Tune, "System Tweaks", "Refresh rate, animations, DND", null) { open("system") }
        }
    }
}

@Composable
fun SubScreen(vm: FairyViewModel, key: String, onBack: () -> Unit) {
    val title: String
    val subtitle: String
    when (key) {
        "perf" -> { title = "Performance Modes"; subtitle = "Peak speed with the heat kept down" }
        "cpu" -> { title = "CPU Core & Frequency"; subtitle = "Live cluster clocks" }
        "charge" -> { title = "Charging Control"; subtitle = "Bypass charging and smart rules" }
        "games" -> { title = "Game List"; subtitle = "Apps that switch to the game profile" }
        else -> { title = "System Tweaks"; subtitle = "Display and system quick switches" }
    }
    Column(modifier = Modifier.fillMaxSize()) {
        SubHeader(title, subtitle, onBack)
        Box(modifier = Modifier.weight(1f)) {
            when (key) {
                "perf" -> PerfScreen(vm)
                "cpu" -> CpuScreen(vm)
                "charge" -> ChargeScreen(vm)
                "games" -> GamesScreen(vm)
                else -> SystemScreen(vm)
            }
        }
    }
}

// ============================================================ PERFORMANCE

@Composable
fun PerfScreen(vm: FairyViewModel) {
    val mode = vm.cfgStr("MODE", "auto")
    val heatOn = vm.cfgStr("HEAT_GUARD", "1") == "1"
    ScreenColumn {
        StatusBanners(vm)
        SectionTitle("Mode")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            ChoiceCard(Modifier.weight(1f), Icons.Rounded.AutoAwesome, "Smart Auto", "Peak in games, cool elsewhere", mode == "auto") { vm.setMode("auto") }
            ChoiceCard(Modifier.weight(1f), Icons.Rounded.AcUnit, "Cool", "Lowest heat, best battery", mode == "low") { vm.setMode("low") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            ChoiceCard(Modifier.weight(1f), Icons.Rounded.Tune, "Balanced", "Smooth and cool all day", mode == "mid") { vm.setMode("mid") }
            ChoiceCard(Modifier.weight(1f), Icons.Rounded.Bolt, "Peak", "Full clocks, heat guard on", mode == "high") { vm.setMode("high") }
        }
        SectionTitle("Heat guard")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            ToggleRow("Heat guard", "Trims the big cores and GPU a little as the phone warms", heatOn, Icons.Rounded.Whatshot) {
                vm.setCfg("HEAT_GUARD", if (it) "1" else "0")
            }
            if (heatOn) {
                GoldSlider("Start trimming at", vm.cfgInt("HEAT_START", 380) / 10, 34, 44, "\u00B0C") {
                    vm.setCfg("HEAT_START", (it * 10).toString())
                }
            }
            ToggleRow("GPU follows the mode", "Applies the same profile and heat guard to the GPU", vm.cfgStr("GPU_CAP", "1") == "1", Icons.Rounded.SportsEsports) {
                vm.setCfg("GPU_CAP", if (it) "1" else "0")
            }
        }
        SectionTitle("Smart Auto profiles")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("While a game is open", color = TextHi, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("mid" to "Balanced", "high" to "Peak"), vm.cfgStr("GAME_MODE", "high")) { vm.setCfg("GAME_MODE", it) }
            Spacer(Modifier.height(14.dp))
            Text("Everywhere else", color = TextHi, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("low" to "Cool", "mid" to "Balanced"), vm.cfgStr("DEFAULT_MODE", "mid")) { vm.setCfg("DEFAULT_MODE", it) }
        }
    }
}

// ============================================================ CPU

@Composable
fun CpuScreen(vm: FairyViewModel) {
    val s = vm.stats
    ScreenColumn {
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = true) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Memory, size = 48.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("CPU topology", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (s.coresTotal > 0) s.cores.toString() + " / " + s.coresTotal + " cores online" else "Reading cores...",
                        color = TextLo, fontSize = 13.sp
                    )
                }
            }
        }
        SectionTitle("Clusters")
        if (s.cpus.isEmpty()) {
            Text("Root access is needed to read live clocks.", color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(6.dp))
        }
        s.cpus.forEachIndexed { i, c ->
            val label = if (i == 0) "Efficiency" else if (i == s.cpus.lastIndex && s.cpus.size >= 3) "Prime" else "Performance"
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(label + " cluster", color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(c.name, color = TextLo, fontSize = 12.sp)
                    }
                    Text(f(c.curKhz / 1_000_000f, 2) + " GHz", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                BarMeter(if (c.maxKhz > 0) c.curKhz.toFloat() / c.maxKhz else 0f)
                Spacer(Modifier.height(6.dp))
                Text("Limit " + f(c.maxKhz / 1_000_000f, 2) + " GHz", color = TextLo, fontSize = 11.sp)
            }
        }
    }
}

// ============================================================ CHARGING

@Composable
fun ChargeScreen(vm: FairyViewModel) {
    val s = vm.stats
    val nodeName = vm.node.trim().split(" ").firstOrNull().orEmpty()
    ScreenColumn {
        StatusBanners(vm)
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = vm.bypassOn) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.BatteryChargingFull, size = 48.dp)
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Bypass Charging", color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    StatusPill(if (vm.bypassOn) "On" else "Off", if (vm.bypassOn) Gold else TextLo)
                }
                GoldSwitch(vm.bypassOn) { vm.setBypass(it) }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Stops charger input and runs the phone from the battery, so charging heat disappears. Works on its own, no engine switch needed.",
                color = TextLo, fontSize = 12.sp, lineHeight = 17.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                if (nodeName.isBlank()) "No charging node detected yet. Run Detect node below." else "Charging node: " + nodeName.substringAfterLast('/'),
                color = if (nodeName.isBlank()) Hot else Gold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
        }

        SectionTitle("Live")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat("Level", s.level.toString() + "%")
                MiniStat("Temp", f(s.tempC, 1) + "\u00B0C", tempColor(s.tempC))
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat("Current", s.currentMa.toString() + " mA")
                MiniStat("Status", s.status)
            }
        }

        SectionTitle("Smart charging")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            ToggleRow("Smart rules", "Used while manual bypass is off", vm.cfgStr("SMART", "1") == "1") {
                vm.setCfg("SMART", if (it) "1" else "0")
            }
            ToggleRow("Bypass in games", "Charger input pauses while a game is open", vm.cfgStr("GAME_BYPASS", "1") == "1") {
                vm.setCfg("GAME_BYPASS", if (it) "1" else "0")
            }
            GoldSlider("Bypass games only above", vm.cfgInt("BYPASS_MIN_BAT", 20), 5, 100, "%") {
                vm.setCfg("BYPASS_MIN_BAT", it.toString())
            }
            GoldSlider("Pause charging above", vm.cfgInt("CHG_HOT", 420) / 10, 38, 48, "\u00B0C") {
                vm.setCfg("CHG_HOT", (it * 10).toString())
            }
            GoldSlider("Charge limit", vm.cfgInt("CHARGE_LIMIT", 0), 0, 100, "%", offLabel = "Off") {
                vm.setCfg("CHARGE_LIMIT", it.toString())
            }
        }

        SectionTitle("Charging node")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                GoldButton("Detect node", Modifier.weight(1f), filled = false) { vm.runTool("detect") }
                GoldButton("Test node", Modifier.weight(1f), filled = false) { vm.runTool("test") }
            }
            if (vm.toolOutput.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(vm.toolOutput, color = TextLo, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 15.sp)
            }
        }
    }
}

// ============================================================ SYSTEM

@Composable
fun SystemScreen(vm: FairyViewModel) {
    LaunchedEffect(Unit) { vm.refreshSystem() }
    ScreenColumn {
        StatusBanners(vm)
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            ToggleRow("Battery saver", "Android low power mode", vm.sys.lowPower, Icons.Rounded.BatteryChargingFull) { vm.setLowPower(it) }
            ToggleRow("Do not disturb", "Silence alerts while you play", vm.sys.dnd, Icons.Rounded.DarkMode) { vm.setDnd(it) }
            ToggleRow("Fast animations", "Shorter window and transition animations", vm.sys.fastAnim, Icons.Rounded.Speed) { vm.setFastAnim(it) }
        }
        SectionTitle("Refresh rate")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Segmented(listOf("auto" to "Auto", "60" to "60", "90" to "90", "120" to "120"), vm.sys.refresh) { vm.setRefresh(it) }
        }
        GoldButton("Clean RAM", Modifier.fillMaxWidth(), filled = false) { vm.cleanRam() }
    }
}

// ============================================================ SETTINGS

@Composable
fun SettingsScreen(vm: FairyViewModel) {
    ScreenColumn {
        ScreenTitle("Settings", "Engine and core")
        StatusBanners(vm)
        GlassCard(modifier = Modifier.fillMaxWidth(), accent = vm.daemon) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Bolt, size = 48.dp)
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Fairy engine", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (vm.coreInstalled) "Core v" + vm.coreVer + " installed" else "Core not installed",
                        color = TextLo, fontSize = 12.sp
                    )
                }
                StatusPill(if (vm.daemon) "Running" else "Stopped", if (vm.daemon) Gold else TextLo)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "The engine starts by itself and keeps your mode, heat guard and bypass applied. You only need these buttons if something looks stuck.",
                color = TextLo, fontSize = 12.sp, lineHeight = 17.sp
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                GoldButton("Restart engine", Modifier.weight(1f)) { vm.restartEngine() }
                GoldButton(if (vm.busy) "Working..." else "Reinstall core", Modifier.weight(1f), filled = false) { vm.installCore() }
            }
        }
    }
}

// ============================================================ SUPPORT (about)

@Composable
private fun LinkCard(icon: ImageVector, label: String, value: String, url: String) {
    val uri = LocalUriHandler.current
    GlassCard(modifier = Modifier.fillMaxWidth(), accent = true, onClick = { runCatching { uri.openUri(url) } }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon, size = 46.dp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(label, color = TextLo, fontSize = 12.sp)
                Text(value, color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Icon(Icons.Rounded.NorthEast, contentDescription = null, tint = Gold)
        }
    }
}

@Composable
fun SupportScreen() {
    val uri = LocalUriHandler.current
    ScreenColumn {
        Box(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(280.dp)) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(Gold.copy(alpha = 0.28f), Color.Transparent), center = center, radius = size.width / 2f),
                    radius = size.width / 2f
                )
            }
            Image(
                painter = painterResource(R.drawable.fairy_team_logo),
                contentDescription = null,
                modifier = Modifier.size(200.dp)
            )
        }
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Fairy Manager", color = TextHi, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill("v1.4")
                StatusPill("Cool peak")
            }
        }
        SectionTitle("Community")
        LinkCard(Icons.Rounded.Send, "Telegram", "t.me/FairysTeamBase", "https://t.me/FairysTeamBase")
        LinkCard(Icons.Rounded.Person, "Built by", "@yooitachiijod", "https://t.me/yooitachiijod")
        Spacer(Modifier.height(4.dp))
        GoldButton("Join our Telegram", Modifier.fillMaxWidth()) { runCatching { uri.openUri("https://t.me/FairysTeamBase") } }
    }
}
