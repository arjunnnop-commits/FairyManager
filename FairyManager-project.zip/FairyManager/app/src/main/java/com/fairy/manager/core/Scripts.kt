package com.fairy.manager.core

import android.content.Context

object Core {
    const val DIR = "/data/adb/pmgr"
    const val GAMES = "/data/adb/pmgr/games.list"
    const val MOD = "/data/adb/modules/pmgr"
    const val BIN = "/data/adb/modules/pmgr/pmgr"
    const val VERSION = 14
}

object Scripts {
    /** Loads assets/scripts/<name> and replaces @KEY@ placeholders. */
    fun load(ctx: Context, name: String, vararg subs: Pair<String, String>): String {
        var text = ctx.assets.open("scripts/$name").bufferedReader().use { it.readText() }
        for ((k, v) in subs) text = text.replace(k, v)
        return text
    }

    /** Keeps only characters that are safe inside a shell string. */
    fun clean(s: String): String = s.filter { it.isLetterOrDigit() || it == '.' || it == '_' || it == '-' }
}
