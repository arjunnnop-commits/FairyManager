package com.fairy.manager.core

data class Cpu(val name: String, val maxKhz: Int, val curKhz: Int)

data class Stats(
    val level: Int = 0,
    val tempC: Float = 0f,
    val currentMa: Int = 0,
    val voltageV: Float = 0f,
    val status: String = "--",
    val cpus: List<Cpu> = emptyList(),
    val memFreeMb: Int = 0,
    val memTotalMb: Int = 0
) {
    val powerW: Float get() = voltageV * currentMa / 1000f
}

data class SysState(
    val lowPower: Boolean = false,
    val dnd: Boolean = false,
    val refresh: String = "auto",
    val fastAnim: Boolean = false
)

data class AppItem(val pkg: String, val name: String, val isGame: Boolean)
