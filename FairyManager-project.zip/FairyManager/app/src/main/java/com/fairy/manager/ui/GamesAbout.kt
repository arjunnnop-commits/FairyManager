package com.fairy.manager.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.fairy.manager.core.AppItem
import com.fairy.manager.core.FairyViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ============================================================ GAMES

@Composable
private fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, pkg) {
        value = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)))
    } else {
        Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)).background(Surface2))
    }
}

@Composable
private fun AppRow(app: AppItem, checked: Boolean, onChange: (Boolean) -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth(), accent = if (checked) Pink else Color(0xFF3A3668)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app.pkg)
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(app.name, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                    if (app.isGame) {
                        Text(
                            "GAME",
                            color = Pink,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Pink.copy(alpha = 0.18f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(app.pkg, color = TextLo, fontSize = 11.sp, maxLines = 1)
            }
            Switch(
                checked = checked,
                onCheckedChange = onChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Pink,
                    uncheckedThumbColor = TextLo,
                    uncheckedTrackColor = Surface2,
                    uncheckedBorderColor = Color(0x33FFFFFF)
                )
            )
        }
    }
}

@Composable
fun GamesScreen(vm: FairyViewModel) {
    LaunchedEffect(Unit) { vm.loadApps() }
    var query by remember { mutableStateOf("") }
    val gamesEmpty = vm.games.isEmpty()
    val shown = remember(vm.apps, query, gamesEmpty) {
        val q = query.trim()
        vm.apps
            .filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) || it.pkg.contains(q, ignoreCase = true) }
            .sortedWith(
                compareByDescending<AppItem> { it.pkg in vm.games }
                    .thenByDescending { it.isGame }
                    .thenBy { it.name.lowercase() }
            )
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { StatusBanners(vm) }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), accent = Pink) {
                Text("🎮  Game Space", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    vm.games.size.toString() + " games added. While one is open, Fairy switches to your in-game profile.",
                    color = TextLo,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                ToggleRow(
                    "Bypass charging in games",
                    "Power the phone straight from the charger while you play",
                    vm.cfgStr("GAME_BYPASS", "1") == "1"
                ) { vm.setCfg("GAME_BYPASS", if (it) "1" else "0") }
                LabeledSlider("Bypass only above", vm.cfgInt("BYPASS_MIN_BAT", 20), 5, 100, "%", Pink) {
                    vm.setCfg("BYPASS_MIN_BAT", it.toString())
                }
                Spacer(Modifier.height(4.dp))
                FairyButton("Auto-add detected games", Modifier.fillMaxWidth(), accent = Pink) { vm.addDetectedGames() }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search apps") },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextHi,
                    unfocusedTextColor = TextHi,
                    focusedBorderColor = Violet,
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    cursorColor = Violet,
                    focusedPlaceholderColor = TextLo,
                    unfocusedPlaceholderColor = TextLo
                )
            )
        }
        if (vm.apps.isEmpty()) {
            item { Text("Loading apps...", color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(8.dp)) }
        }
        items(shown, key = { it.pkg }) { app ->
            AppRow(app, app.pkg in vm.games) { vm.toggleGame(app.pkg, it) }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

// ============================================================ ABOUT

@Composable
private fun InfoRow(glyph: String, label: String, value: String, link: Boolean, onClick: (() -> Unit)?) {
    GlassCard(modifier = Modifier.fillMaxWidth(), accent = if (link) Cyan else Violet, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(glyph, fontSize = 24.sp)
            Column(modifier = Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(label, color = TextLo, fontSize = 12.sp)
                Text(value, color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            if (link) Text("↗", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val uri = LocalUriHandler.current
    val open: (String) -> Unit = { url ->
        try {
            uri.openUri(url)
        } catch (e: Exception) {
        }
    }
    val t = rememberInfiniteTransition(label = "about")
    val bob by t.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val pulse by t.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(modifier = Modifier.fillMaxSize().background(Bg)) {
        AuroraBackground(Modifier.fillMaxSize())
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Surface2)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Text("←", color = TextHi, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Box(modifier = Modifier.size(260.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f * pulse
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Violet.copy(alpha = 0.55f), Cyan.copy(alpha = 0.12f), Color.Transparent),
                            center = center,
                            radius = r
                        ),
                        radius = r,
                        center = center
                    )
                }
                FairyLogo(
                    size = 160.dp,
                    modifier = Modifier.graphicsLayer { translationY = bob * density }
                )
            }
            Spacer(Modifier.height(8.dp))
            InfoRow("📦", "APK Name", "Fairy Manager", false, null)
            InfoRow("👨‍💻", "Built by", "@yooitachiijod", true) { open("https://t.me/yooitachiijod") }
            InfoRow("✈️", "Telegram", "t.me/FairysTeamBase", true) { open("https://t.me/FairysTeamBase") }
            InfoRow("🧩", "Version", "1.0", false, null)
            Spacer(Modifier.height(4.dp))
            FairyButton("Join our Telegram", Modifier.fillMaxWidth(), accent = Cyan) { open("https://t.me/FairysTeamBase") }
            Spacer(Modifier.height(16.dp))
        }
    }
}
