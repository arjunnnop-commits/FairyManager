package com.fairy.manager.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.fairy.manager.core.AppItem
import com.fairy.manager.core.FairyViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, pkg) {
        value = withContext(Dispatchers.IO) {
            try {
                ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)))
    } else {
        Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Surface2))
    }
}

@Composable
private fun AppRow(app: AppItem, checked: Boolean, onChange: (Boolean) -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth(), accent = checked) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app.pkg)
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(app.name, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                    if (app.isGame) {
                        Text(
                            "GAME",
                            color = Gold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Gold.copy(alpha = 0.16f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(app.pkg, color = TextLo, fontSize = 11.sp, maxLines = 1)
            }
            GoldSwitch(checked, onChange)
        }
    }
}

@Composable
fun GamesScreen(vm: FairyViewModel) {
    LaunchedEffect(Unit) { vm.loadApps() }
    var query by remember { mutableStateOf("") }
    val gamesCount = vm.games.size
    val shown = remember(vm.apps, query, gamesCount) {
        val q = query.trim()
        vm.apps
            .filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) || it.pkg.contains(q, ignoreCase = true) }
            .sortedWith(
                compareByDescending<AppItem> { it.pkg in vm.games }
                    .thenByDescending { it.isGame }
                    .thenBy { it.name.lowercase() }
            )
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { StatusBanners(vm) }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth(), accent = true) {
                Text(gamesCount.toString() + " games added", color = TextHi, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    "While one is open, Fairy switches to your game profile and can pause charging to keep the phone cool.",
                    color = TextLo, fontSize = 12.sp, lineHeight = 16.sp
                )
                Spacer(Modifier.height(10.dp))
                GoldButton("Auto-add detected games", Modifier.fillMaxWidth()) { vm.addDetectedGames() }
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                placeholder = { Text("Search apps") },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextHi,
                    unfocusedTextColor = TextHi,
                    focusedBorderColor = Gold,
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    cursorColor = Gold,
                    focusedPlaceholderColor = TextLo,
                    unfocusedPlaceholderColor = TextLo
                )
            )
        }
        if (vm.apps.isEmpty()) {
            item { Text("Loading apps...", color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(8.dp)) }
        }
        items(shown, key = { it.pkg }) { app ->
            AppRow(app, app.pkg in vm.games) { vm.toggleGame(app.pkg, it) }
        }
    }
}
