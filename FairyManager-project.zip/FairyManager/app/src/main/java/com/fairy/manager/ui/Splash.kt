package com.fairy.manager.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.fairy.manager.R

@Composable
fun SplashOverlay(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        a.animateTo(1f, tween(450))
        kotlinx.coroutines.delay(500)
        a.animateTo(0f, tween(300))
        onDone()
    }
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        FairyBackground(Modifier.fillMaxSize())
        Image(
            painter = painterResource(R.drawable.fairy_team_logo),
            contentDescription = null,
            modifier = Modifier.size(170.dp).alpha(a.value)
        )
    }
}
