package com.fairy.manager.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairy.manager.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SplashOverlay(onDone: () -> Unit) {
    val logoScale = remember { Animatable(0.2f) }
    val logoAlpha = remember { Animatable(0f) }
    val ring = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }

    val inf = rememberInfiniteTransition(label = "splash")
    val spin by inf.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "spin"
    )
    val twinkle by inf.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "twinkle"
    )

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { ring.animateTo(1f, tween(1500, easing = FastOutSlowInEasing)) }
            launch {
                delay(250)
                logoAlpha.animateTo(1f, tween(500))
            }
            launch {
                delay(250)
                logoScale.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessLow))
            }
            launch {
                delay(1000)
                textAlpha.animateTo(1f, tween(700))
            }
        }
        delay(800)
        exit.animateTo(0f, tween(450))
        onDone()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .alpha(exit.value)
            .background(Bg)
            .clickable(enabled = false) { },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val c = center
            val md = size.minDimension
            val glowR = md * 0.75f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Violet.copy(alpha = 0.40f * ring.value), Color.Transparent),
                    center = c,
                    radius = glowR
                ),
                radius = glowR,
                center = c
            )
            val r1 = md * 0.28f
            drawArc(
                color = Cyan,
                startAngle = spin,
                sweepAngle = 270f * ring.value,
                useCenter = false,
                topLeft = Offset(c.x - r1, c.y - r1),
                size = Size(2f * r1, 2f * r1),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
            val r2 = r1 * 1.22f
            drawArc(
                color = Violet,
                startAngle = -spin * 1.5f,
                sweepAngle = 140f * ring.value,
                useCenter = false,
                topLeft = Offset(c.x - r2, c.y - r2),
                size = Size(2f * r2, 2f * r2),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
            val r3 = r1 * 1.46f
            drawArc(
                color = Pink,
                startAngle = spin * 0.8f + 90f,
                sweepAngle = 60f * ring.value,
                useCenter = false,
                topLeft = Offset(c.x - r3, c.y - r3),
                size = Size(2f * r3, 2f * r3),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )
            // twinkling fairy dust
            val colors = listOf(Color.White, Cyan, Pink, Color(0xFFFDE047))
            for (i in 0 until 22) {
                val ang = i * 2.399f + spin * (PI.toFloat() / 180f) * 0.15f
                val dist = md * (0.16f + 0.34f * (((i * 37) % 100) / 100f))
                val a = (0.5f + 0.5f * sin(twinkle + i * 0.7f)) * ring.value
                val px = c.x + cos(ang) * dist
                val py = c.y + sin(ang) * dist
                val rad = (1.5f + (i % 3)) * density
                val col = colors[i % colors.size].copy(alpha = a)
                drawCircle(color = col, radius = rad, center = Offset(px, py))
                drawLine(col, Offset(px - rad * 2.2f, py), Offset(px + rad * 2.2f, py), strokeWidth = 1f)
                drawLine(col, Offset(px, py - rad * 2.2f), Offset(px, py + rad * 2.2f), strokeWidth = 1f)
            }
        }

        Image(
            painter = painterResource(R.drawable.fairy_logo),
            contentDescription = null,
            modifier = Modifier
                .size(132.dp)
                .graphicsLayer {
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                    alpha = logoAlpha.value
                    rotationZ = (1f - logoScale.value.coerceAtMost(1f)) * -25f
                }
        )

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 175.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "FAIRY MANAGER",
                color = TextHi,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 6.sp,
                modifier = Modifier.graphicsLayer {
                    alpha = textAlpha.value
                    translationY = (1f - textAlpha.value) * 24f
                }
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "POWER  •  PERFORMANCE  •  BATTERY",
                color = Cyan,
                fontSize = 10.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.graphicsLayer {
                    alpha = textAlpha.value
                    translationY = (1f - textAlpha.value) * 16f
                }
            )
            Spacer(Modifier.height(22.dp))
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Surface2)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(ring.value)
                        .background(Brush.horizontalGradient(listOf(Violet, Cyan)))
                )
            }
        }
    }
}
