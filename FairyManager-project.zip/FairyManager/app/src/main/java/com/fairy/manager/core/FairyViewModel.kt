package com.fairy.manager.core
import android.content.pm.ApplicationInfo
import android.app.Application
import android.content.ApplicationInfo
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import kotlin.math.max

private fun parseKv(raw: String): Map<String, String> {
    val m = HashMap<String, String>()
    for (line in raw.lines()) {
        val i = line.indexOf('=')
        if (i > 0) m[line.substring(0, i).trim()] = line.substring(i + 1).trim()
    }
    return m
}

class FairyViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val stateLock = Any()
    @Volatile private var active = true

    var root by mutableStateOf<Boolean?>(null)
    var stats by mutableStateOf(Stats())
    var cfg by mutableStateOf<Map<String, String>>(emptyMap())
    var games by mutableStateOf<Set<String>>(emptySet())
    var daemon by mutableStateOf(false)
    var coreInstalled by mutableStateOf(true)
    var coreVer by mutableStateOf(0)
    var node by mutableStateOf("")
    var sys by mutableStateOf(SysState())
    var toolOutput by mutableStateOf("")
    var busy by mutableStateOf(false)
    var apps by mutableStateOf<List<AppItem>>(emptyList())
    var toast by mutableStateOf<String?>(null)

    fun cfgInt(k: String, def: Int): Int = cfg[k]?.toIntOrNull() ?: def
    fun cfgStr(k: String, def: String): String = cfg[k] ?: def

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = Root.check()
            root = ok
            if (ok) {
                Root.sh(Scripts.load(ctx, "init.sh"))
                loadSystem()
            }
            while (isActive) {
                if (active) {
                    if (root == true) refreshRoot() else refreshPlain()
                }
                delay(2000)
            }
        }
    }

    fun setActive(a: Boolean) {
        active = a
        if (a && root == true) io { refreshRoot() }
    }

    private fun io(block: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) { block() }
    }

    private fun needRoot(): Boolean {
        if (root != true) {
            toast = "Root access required"
            return false
        }
        return true
    }

    fun retryRoot() {
        io {
            root = null
            val ok = Root.check()
            root = ok
            if (ok) {
                Root.sh(Scripts.load(ctx, "init.sh"))
                loadSystem()
                refreshRoot()
            }
        }
    }

    // ------------------------------------------------------------------ polling

    private fun refreshRoot() {
        synchronized(stateLock) {
            val raw = Root.sh(Scripts.load(ctx, "stats.sh"))
            if (raw.isEmpty()) return
            val m = HashMap<String, String>()
            val cpus = ArrayList<Cpu>()
            val g = LinkedHashSet<String>()
            var inGames = false
            for (line in raw.lines()) {
                if (line.trim() == "##GAMES") {
                    inGames = true
                    continue
                }
                if (inGames) {
                    if (line.isNotBlank()) g.add(line.trim())
                    continue
                }
                val i = line.indexOf('=')
                if (i <= 0) continue
                val k = line.substring(0, i).trim()
                val v = line.substring(i + 1).trim()
                if (k == "cpu") {
                    val p = v.split(",")
                    if (p.size >= 3) cpus.add(Cpu(p[0], p[1].toIntOrNull() ?: 0, p[2].toIntOrNull() ?: 0))
                } else {
                    m[k] = v
                }
            }
            val curRaw = abs(m["cur"]?.toLongOrNull() ?: 0L)
            val ma = if (curRaw >= 20000L) curRaw / 1000L else curRaw
            val vRaw = m["volt"]?.toLongOrNull() ?: 0L
            val volts = when {
                vRaw > 100000L -> vRaw / 1_000_000f
                vRaw > 1000L -> vRaw / 1000f
                else -> vRaw.toFloat()
            }
            stats = Stats(
                level = m["cap"]?.toIntOrNull() ?: stats.level,
                tempC = (m["temp"]?.toFloatOrNull() ?: 0f) / 10f,
                currentMa = ma.toInt(),
                voltageV = volts,
                status = (m["status"] ?: "").ifBlank { "--" },
                cpus = cpus,
                memFreeMb = ((m["mem"]?.toLongOrNull() ?: 0L) / 1024L).toInt(),
                memTotalMb = ((m["memtotal"]?.toLongOrNull() ?: 0L) / 1024L).toInt()
            )
            daemon = m["daemon"] == "1"
            coreInstalled = m["core"] == "1"
            coreVer = m["corever"]?.toIntOrNull() ?: 0
            node = m["node"] ?: ""
            cfg = m.filterKeys { k -> k.isNotEmpty() && k.all { it.isUpperCase() || it == '_' } }
            games = g
        }
    }

    private fun refreshPlain() {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = max(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
        val st = when (i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
            else -> "--"
        }
        stats = Stats(
            level = lvl * 100 / scale,
            tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f,
            voltageV = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f,
            status = st
        )
    }

    private fun loadSystem() {
        val m = parseKv(Root.sh(Scripts.load(ctx, "system.sh")))
        val peak = m["peak"]?.toFloatOrNull()?.toInt()
        sys = SysState(
            lowPower = m["lowpower"] == "1",
            dnd = (m["zen"]?.toIntOrNull() ?: 0) != 0,
            refresh = if (peak != null && peak > 0) peak.toString() else "auto",
            fastAnim = (m["anim"]?.toFloatOrNull() ?: 1f) < 1f
        )
    }

    fun refreshSystem() {
        if (root == true) io { loadSystem() }
    }

    // ------------------------------------------------------------------ config

    private fun writeCfg(k: String, v: String) {
        synchronized(stateLock) {
            val ks = Scripts.clean(k)
            val vs = Scripts.clean(v)
            Root.sh(Scripts.load(ctx, "setcfg.sh", "@K@" to ks, "@V@" to vs))
            cfg = cfg + (ks to vs)
        }
    }

    fun setCfg(k: String, v: String) {
        if (!needRoot()) return
        io { writeCfg(k, v) }
    }

    fun setMode(mode: String) = setCfg("MODE", mode)

    // ------------------------------------------------------------------ games

    fun loadApps() {
        if (apps.isNotEmpty()) return
        io {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val list = pm.queryIntentActivities(intent, 0)
            val out = LinkedHashMap<String, AppItem>()
            for (ri in list) {
                val ai = ri.activityInfo?.applicationInfo ?: continue
                val pkg = ai.packageName
                if (pkg == ctx.packageName || out.containsKey(pkg)) continue
                @Suppress("DEPRECATION")
                val game = ai.category == ApplicationInfo.CATEGORY_GAME ||
                    (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                out[pkg] = AppItem(pkg, ri.loadLabel(pm).toString(), game)
            }
            apps = out.values.sortedBy { it.name.lowercase() }
        }
    }

    fun toggleGame(pkg: String, on: Boolean) {
        if (!needRoot()) return
        io {
            synchronized(stateLock) {
                val p = Scripts.clean(pkg)
                val g = Core.GAMES
                if (on) {
                    Root.sh("echo '$p' >> $g; sort -u $g -o $g")
                    games = games + pkg
                } else {
                    Root.sh("grep -vxF '$p' $g > $g.tmp; cat $g.tmp > $g; rm -f $g.tmp")
                    games = games - pkg
                }
            }
        }
    }

    fun addDetectedGames() {
        if (!needRoot()) return
        val found = apps.filter { it.isGame && it.pkg !in games }
        if (found.isEmpty()) {
            toast = "No new games detected"
            return
        }
        io {
            synchronized(stateLock) {
                val g = Core.GAMES
                val adds = found.joinToString("\n") { "echo '" + Scripts.clean(it.pkg) + "' >> " + g }
                Root.sh(adds + "\nsort -u " + g + " -o " + g)
                games = games + found.map { it.pkg }
            }
            toast = "Added " + found.size + " games"
        }
    }

    // ------------------------------------------------------------------ quick actions

    fun toggleBoost() {
        if (!needRoot()) return
        val on = cfgStr("MODE", "auto") == "high"
        io {
            if (on) {
                writeCfg("MODE", "auto")
                Root.sh("settings put global zen_mode 0")
                toast = "Game Boost off"
            } else {
                writeCfg("MODE", "high")
                Root.sh("settings put global zen_mode 1; am kill-all")
                toast = "Game Boost on: Performance + DND + RAM clean"
            }
            loadSystem()
        }
    }

    fun toggleSaver() {
        if (!needRoot()) return
        val on = cfgStr("MODE", "auto") == "low"
        io {
            if (on) {
                writeCfg("MODE", "auto")
                Root.sh("settings put global low_power 0")
                toast = "Battery Saver off"
            } else {
                writeCfg("MODE", "low")
                Root.sh("settings put global low_power 1")
                toast = "Battery Saver on"
            }
            loadSystem()
        }
    }

    fun cleanRam() {
        if (!needRoot()) return
        io {
            val before = stats.memFreeMb
            Root.sh("am kill-all; sync; echo 3 > /proc/sys/vm/drop_caches")
            Thread.sleep(900)
            refreshRoot()
            val freed = max(0, stats.memFreeMb - before)
            toast = "RAM cleaned: +" + freed + " MB free"
        }
    }

    fun setLowPower(on: Boolean) {
        if (!needRoot()) return
        io {
            Root.sh("settings put global low_power " + (if (on) "1" else "0"))
            loadSystem()
        }
    }

    fun setDnd(on: Boolean) {
        if (!needRoot()) return
        io {
            Root.sh("settings put global zen_mode " + (if (on) "1" else "0"))
            loadSystem()
        }
    }

    fun setFastAnim(on: Boolean) {
        if (!needRoot()) return
        io {
            val v = if (on) "0.5" else "1.0"
            Root.sh(
                "settings put global window_animation_scale $v; " +
                    "settings put global transition_animation_scale $v; " +
                    "settings put global animator_duration_scale $v"
            )
            loadSystem()
        }
    }

    fun setRefresh(hz: String) {
        if (!needRoot()) return
        io {
            if (hz == "auto") {
                Root.sh("settings delete system peak_refresh_rate; settings delete system min_refresh_rate")
            } else {
                val h = Scripts.clean(hz)
                Root.sh("settings put system peak_refresh_rate $h; settings put system min_refresh_rate $h")
            }
            loadSystem()
        }
    }

    // ------------------------------------------------------------------ core / tools

    fun setDaemon(on: Boolean) {
        if (!needRoot()) return
        if (!coreInstalled) {
            toast = "Install the core first (Tools tab)"
            return
        }
        io {
            if (on) {
                Root.long(Scripts.load(ctx, "daemon_start.sh"))
            } else {
                Root.long("sh " + Core.BIN + " stop")
            }
            refreshRoot()
        }
    }

    fun installCore() {
        if (!needRoot() || busy) return
        busy = true
        io {
            try {
                val dir = File(ctx.cacheDir, "core")
                dir.mkdirs()
                for (n in listOf("pmgr", "module.prop", "service.sh")) {
                    ctx.assets.open("core/$n").use { input ->
                        File(dir, n).outputStream().use { output -> input.copyTo(output) }
                    }
                }
                val r = Root.long(Scripts.load(ctx, "install_core.sh", "@SRC@" to dir.absolutePath))
                if (r.contains("installed")) {
                    Root.long("sh " + Core.BIN + " stop")
                    Root.long(Scripts.load(ctx, "daemon_start.sh"))
                    toast = "Core installed and engine started"
                } else {
                    toast = "Install failed: $r"
                }
            } catch (e: Exception) {
                toast = "Install failed: " + (e.message ?: "unknown error")
            } finally {
                busy = false
                refreshRoot()
            }
        }
    }

    fun runTool(cmd: String) {
        if (!needRoot() || busy) return
        if (!coreInstalled) {
            toast = "Install the core first"
            return
        }
        busy = true
        val hint = if (cmd == "test" || cmd == "probe") " (keep the charger connected, up to 40 s)" else ""
        toolOutput = "Running $cmd ...$hint"
        io {
            val out = Root.long("sh " + Core.BIN + " " + cmd + " 2>&1")
            toolOutput = out.ifBlank { "(no output)" }
            busy = false
        }
    }
}
