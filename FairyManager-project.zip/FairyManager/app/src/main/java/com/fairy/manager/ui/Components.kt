package com.fairy.manager.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fairy.manager.R
import kotlin.math.roundToInt

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    accent: Color = Violet,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    val base = modifier
        .clip(shape)
        .background(Brush.linearGradient(listOf(Surface2, Surface1)))
        .border(
            1.dp,
            Brush.linearGradient(listOf(accent.copy(alpha = 0.55f), Color.White.copy(alpha = 0.05f))),
            shape
        )
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(modifier = m.padding(16.dp), content = content)
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        color = TextLo,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        modifier = modifier.padding(start = 4.dp, top = 4.dp)
    )
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(sub, color = TextLo, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Violet,
                uncheckedThumbColor = TextLo,
                uncheckedTrackColor = Surface2,
                uncheckedBorderColor = Color(0x33FFFFFF)
            )
        )
    }
}

@Composable
fun Segmented(
    options: List<Pair<String, String>>,
    selected: String,
    accent: Color = Violet,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Bg.copy(alpha = 0.6f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { (value, label) ->
            val sel = value == selected
            val bg by animateColorAsState(if (sel) accent else Color.Transparent, label = "seg")
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(11.dp))
                    .background(bg)
                    .clickable { onSelect(value) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (sel) Color.White else TextLo,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun LabeledSlider(
    title: String,
    value: Int,
    min: Int,
    max: Int,
    unit: String,
    accent: Color = Violet,
    enabled: Boolean = true,
    onCommit: (Int) -> Unit
) {
    var v by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = TextHi, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(v.roundToInt().toString() + unit, color = accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = v,
            onValueChange = { v = it },
            onValueChangeFinished = { onCommit(v.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat(),
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = Surface2,
                disabledThumbColor = TextLo,
                disabledActiveTrackColor = TextLo.copy(alpha = 0.5f),
                disabledInactiveTrackColor = Surface2
            )
        )
    }
}

@Composable
fun FairyButton(
    text: String,
    modifier: Modifier = Modifier,
    accent: Color = Violet,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.65f))))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun FairyLogo(size: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.fairy_logo),
        contentDescription = null,
        modifier = modifier.size(size)
    )
}

/** Soft animated aurora glow used behind every screen. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val drift by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRect(Bg)
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Violet.copy(alpha = 0.30f), Color.Transparent),
                center = Offset(w * (0.2f + 0.25f * drift), h * 0.10f),
                radius = w * 0.9f
            ),
            radius = w * 0.9f,
            center = Offset(w * (0.2f + 0.25f * drift), h * 0.10f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Cyan.copy(alpha = 0.16f), Color.Transparent),
                center = Offset(w * (0.9f - 0.25f * drift), h * 0.85f),
                radius = w * 0.8f
            ),
            radius = w * 0.8f,
            center = Offset(w * (0.9f - 0.25f * drift), h * 0.85f)
        )
    }
}
