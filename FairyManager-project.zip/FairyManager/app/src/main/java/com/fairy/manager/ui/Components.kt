package com.fairy.manager.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Pure black AMOLED background with soft gold light at the top and bottom. */
@Composable
fun FairyBackground(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        drawRect(Bg)
        val r1 = size.width * 0.95f
        val c1 = Offset(size.width * 0.12f, 0f)
        drawCircle(
            brush = Brush.radialGradient(listOf(Gold.copy(alpha = 0.16f), Color.Transparent), center = c1, radius = r1),
            radius = r1,
            center = c1
        )
        val r2 = size.width * 1.1f
        val c2 = Offset(size.width * 0.5f, size.height * 1.02f)
        drawCircle(
            brush = Brush.radialGradient(listOf(Gold.copy(alpha = 0.12f), Color.Transparent), center = c2, radius = r2),
            radius = r2,
            center = c2
        )
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    accent: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    val border = if (accent) {
        Brush.linearGradient(listOf(Gold.copy(alpha = 0.75f), Gold.copy(alpha = 0.10f)))
    } else {
        Brush.linearGradient(listOf(Color(0x30FFFFFF), Color(0x0AFFFFFF)))
    }
    val fill = if (accent) {
        Brush.linearGradient(listOf(Gold.copy(alpha = 0.13f), Color(0x08FFFFFF)))
    } else {
        Brush.linearGradient(listOf(Color(0x18FFFFFF), Color(0x07FFFFFF)))
    }
    var m = modifier.clip(shape).background(fill).border(1.dp, border, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(modifier = m.padding(16.dp), content = content)
}

@Composable
fun IconTile(icon: ImageVector, tint: Color = Gold, size: Dp = 44.dp) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = Modifier
            .size(size)
            .clip(shape)
            .background(tint.copy(alpha = 0.12f))
            .border(1.dp, tint.copy(alpha = 0.28f), shape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.52f))
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        color = TextLo,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.6.sp,
        modifier = modifier.padding(start = 6.dp, top = 6.dp)
    )
}

@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        content()
        Spacer(Modifier.height(120.dp))
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 4.dp)) {
        Text(title, color = TextHi, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = TextLo, fontSize = 14.sp)
    }
}

@Composable
fun SubHeader(title: String, subtitle: String, onBack: () -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0x14FFFFFF))
                    .border(1.dp, Hairline, CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextHi, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
            Text(title, color = TextHi, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Text(subtitle, color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
    }
}

@Composable
fun StatusPill(text: String, color: Color = Gold) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .clip(shape)
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.35f), shape)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text.uppercase(), color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
fun GoldSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.Black,
            checkedTrackColor = Gold,
            checkedBorderColor = Gold,
            uncheckedThumbColor = TextLo,
            uncheckedTrackColor = Color(0x14FFFFFF),
            uncheckedBorderColor = Color(0x33FFFFFF)
        )
    )
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, icon: ImageVector? = null, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            IconTile(icon, size = 40.dp)
            Spacer(Modifier.width(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = TextLo, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        GoldSwitch(checked, onChange)
    }
}

@Composable
fun ChoiceCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    sub: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    GlassCard(modifier = modifier, accent = selected, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon, tint = if (selected) Gold else TextLo, size = 36.dp)
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, if (selected) Gold else Color(0x55FFFFFF), CircleShape)
                    .background(if (selected) Gold else Color.Transparent)
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = TextLo, fontSize = 11.sp, lineHeight = 14.sp)
    }
}

@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0x0FFFFFFF))
            .border(1.dp, Hairline, shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for ((key, label) in options) {
            val on = key == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (on) Gold else Color.Transparent)
                    .clickable { onSelect(key) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (on) Color.Black else TextLo, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun GoldSlider(label: String, value: Int, min: Int, max: Int, unit: String, offLabel: String? = null, onDone: (Int) -> Unit) {
    var v by remember(value) { mutableStateOf(value.toFloat()) }
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = TextHi, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            val shown = if (offLabel != null && v.toInt() <= min) offLabel else v.toInt().toString() + unit
            Text(shown, color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = v,
            onValueChange = { v = it },
            onValueChangeFinished = { onDone(v.toInt()) },
            valueRange = min.toFloat()..max.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = Gold,
                activeTrackColor = Gold,
                inactiveTrackColor = Color(0x22FFFFFF)
            )
        )
    }
}

@Composable
fun GoldButton(text: String, modifier: Modifier = Modifier, filled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val base = modifier.clip(shape)
    val styled = if (filled) {
        base.background(Brush.horizontalGradient(listOf(GoldSoft, Gold)))
    } else {
        base.background(Gold.copy(alpha = 0.08f)).border(1.dp, Gold.copy(alpha = 0.55f), shape)
    }
    Box(
        modifier = styled.clickable(onClick = onClick).padding(vertical = 14.dp, horizontal = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (filled) Color.Black else Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun RingGauge(fraction: Float, center: String, caption: String, size: Dp = 128.dp) {
    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 11.dp.toPx()
            val inset = stroke
            val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
            val tl = Offset(inset, inset)
            drawArc(Color(0x14FFFFFF), -90f, 360f, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            val sweep = 360f * fraction.coerceIn(0f, 1f)
            drawArc(Gold.copy(alpha = 0.20f), -90f, sweep, false, tl, arcSize, style = Stroke(stroke * 1.9f, cap = StrokeCap.Round))
            drawArc(Gold, -90f, sweep, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(center, color = TextHi, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(caption, color = TextLo, fontSize = 11.sp)
        }
    }
}

@Composable
fun BarMeter(fraction: Float, modifier: Modifier = Modifier, color: Color = Gold) {
    val shape = RoundedCornerShape(50)
    Box(modifier = modifier.fillMaxWidth().height(8.dp).clip(shape).background(Color(0x14FFFFFF))) {
        Box(
            modifier = Modifier
                .fillMaxWidth(fraction.coerceIn(0.02f, 1f))
                .height(8.dp)
                .clip(shape)
                .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.6f), color)))
        )
    }
}
