M=/data/adb/modules/pmgr
mkdir -p $M /data/adb/pmgr
cp -f @SRC@/pmgr $M/pmgr
cp -f @SRC@/module.prop $M/module.prop
cp -f @SRC@/service.sh $M/service.sh
chmod 755 $M/pmgr $M/service.sh
chmod 644 $M/module.prop
chown 0:0 $M/pmgr $M/service.sh $M/module.prop 2>/dev/null
echo installed
