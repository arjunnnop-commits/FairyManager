F=/data/adb/pmgr/config
mkdir -p /data/adb/pmgr
touch $F
if grep -q "^@K@=" $F; then
  sed -i "s|^@K@=.*|@K@=@V@|" $F
else
  echo "@K@=@V@" >> $F
fi
