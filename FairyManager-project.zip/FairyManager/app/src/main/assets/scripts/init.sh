D=/data/adb/pmgr
mkdir -p $D
[ -f $D/games.list ] || : > $D/games.list
touch $D/config
for kv in MODE=auto DEFAULT_MODE=mid GAME_MODE=high GAME_BYPASS=1 BYPASS=auto BYPASS_MIN_BAT=20 CHARGE_LIMIT=0 TEMP_LIMIT=450 LOW_PCT=45 MID_PCT=70; do
  k=${kv%%=*}
  grep -q "^$k=" $D/config || echo "$kv" >> $D/config
done
echo ok
