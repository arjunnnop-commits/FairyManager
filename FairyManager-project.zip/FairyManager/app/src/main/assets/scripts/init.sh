D=/data/adb/pmgr
mkdir -p $D
[ -f $D/games.list ] || : > $D/games.list
touch $D/config
for kv in MODE=auto DEFAULT_MODE=mid GAME_MODE=high GAME_BYPASS=1 BYPASS=off SMART=1 BYPASS_MIN_BAT=20 CHARGE_LIMIT=0 HEAT_GUARD=1 HEAT_START=380 GPU_CAP=1 CHG_HOT=420 LOW_PCT=50 MID_PCT=75; do
  k=${kv%%=*}
  grep -q "^$k=" $D/config || echo "$kv" >> $D/config
done
echo ok
