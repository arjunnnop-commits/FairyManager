BIN=/data/adb/modules/pmgr/pmgr
chmod 755 $BIN
if command -v setsid >/dev/null 2>&1; then
  setsid nohup sh $BIN daemon >/dev/null 2>&1 </dev/null &
else
  nohup sh $BIN daemon >/dev/null 2>&1 </dev/null &
fi
sleep 1
echo started
