echo "lowpower=$(settings get global low_power)"
echo "zen=$(settings get global zen_mode)"
echo "peak=$(settings get system peak_refresh_rate)"
echo "anim=$(settings get global window_animation_scale)"
