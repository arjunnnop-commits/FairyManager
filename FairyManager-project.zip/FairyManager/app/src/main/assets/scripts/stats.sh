B=/sys/class/power_supply/battery
echo "cap=$(cat $B/capacity 2>/dev/null)"
echo "temp=$(cat $B/temp 2>/dev/null)"
echo "cur=$(cat $B/current_now 2>/dev/null)"
echo "volt=$(cat $B/voltage_now 2>/dev/null)"
echo "status=$(cat $B/status 2>/dev/null)"
for p in /sys/devices/system/cpu/cpufreq/policy*; do
  echo "cpu=$(basename $p),$(cat $p/scaling_max_freq 2>/dev/null),$(cat $p/scaling_cur_freq 2>/dev/null)"
done
echo "mem=$(grep MemAvailable /proc/meminfo | tr -s " " | cut -d" " -f2)"
echo "memtotal=$(grep MemTotal /proc/meminfo | tr -s " " | cut -d" " -f2)"
if [ -f /data/adb/pmgr/pid ] && kill -0 "$(cat /data/adb/pmgr/pid)" 2>/dev/null; then echo "daemon=1"; else echo "daemon=0"; fi
if [ -f /data/adb/modules/pmgr/pmgr ]; then echo "core=1"; else echo "core=0"; fi
echo "corever=$(grep -m1 -o "PMGR_VER=[0-9]*" /data/adb/modules/pmgr/pmgr 2>/dev/null | cut -d= -f2)"
echo "node=$(cat /data/adb/pmgr/node 2>/dev/null)"
cat /data/adb/pmgr/config 2>/dev/null
echo
echo "##GAMES"
cat /data/adb/pmgr/games.list 2>/dev/null
