#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
M=/data/adb/modules/pmgr
chmod 755 $M/pmgr
for d in /data/adb/ksu/bin /data/adb/magisk /data/adb/ap/bin; do
  [ -d "$d" ] && ln -sf $M/pmgr $d/pmgr
done
sleep 15
$M/pmgr daemon >/dev/null 2>&1 &
